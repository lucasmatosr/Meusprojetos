﻿using MySqlConnector;
using System.Data;

namespace TEP_Prova3_50
{
    class ConexaoBD
    {
        private MySqlConnection conexao;

        public void conectarbd()
        {
            conexao = new MySqlConnection("persist security info = false;" +
                                          "server=localhost;" +
                                          "database=Prova_TEP_E;" +
                                          "uid=root;pwd=;SslMode=none");
            conexao.Open();
        }
        public void AlterarTabelas(string sql)
        {
            conectarbd();
            MySqlCommand comandos = new MySqlCommand(sql, conexao);
            comandos.ExecuteNonQuery();
            conexao.Close();
        }
        public DataTable ConsutarTabelas(string sql)
        {
            conectarbd();
            MySqlDataAdapter consulta = new MySqlDataAdapter(sql, conexao);
            DataTable resultado = new DataTable();
            consulta.Fill(resultado);
            conexao.Close();
            return resultado;
        }
    }
}
