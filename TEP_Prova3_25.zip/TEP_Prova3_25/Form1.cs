﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TEP_Prova3_50
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ConexaoBD bd = new ConexaoBD();
        string sql;

       

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            limpar();
        }
        public void limpar()
        {
            txtid.Clear();
            txtmodelo.Clear();
            txttamanho.Clear();
            txtcor.Clear();

        }
        private void btncadastrar_Click(object sender, EventArgs e)
        {
            sql = string.Format("insert into camisa value(null,'{0}','{1}','{2}')"
               , txtmodelo.Text, txttamanho.Text, txtcor.Text);

            bd.AlterarTabelas(sql);
            MessageBox.Show("Roupa cadastrado com sucesso!!!", "Cadastro de Roupa", MessageBoxButtons.OK, MessageBoxIcon.Information);

            limpar();
        }

        private void btnlistar_Click(object sender, EventArgs e)
        {
            listar();
        }
        public void listar()
        {
            sql = "select * from camisa";
            dgvlistar.DataSource = bd.ConsutarTabelas(sql);

        }
    }
}
