﻿
namespace TEP_Prova3_50
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txttamanho = new System.Windows.Forms.TextBox();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnlistar = new System.Windows.Forms.Button();
            this.btncadastrar = new System.Windows.Forms.Button();
            this.txtmodelo = new System.Windows.Forms.TextBox();
            this.dgvlistar = new System.Windows.Forms.DataGridView();
            this.txtcor = new System.Windows.Forms.TextBox();
            this.txtid = new System.Windows.Forms.TextBox();
            this.lblmodelo = new System.Windows.Forms.Label();
            this.lbltamanho = new System.Windows.Forms.Label();
            this.lblplaca = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvlistar)).BeginInit();
            this.SuspendLayout();
            // 
            // txttamanho
            // 
            this.txttamanho.Location = new System.Drawing.Point(52, 119);
            this.txttamanho.Name = "txttamanho";
            this.txttamanho.Size = new System.Drawing.Size(99, 23);
            this.txttamanho.TabIndex = 79;
            // 
            // btnlimpar
            // 
            this.btnlimpar.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btnlimpar.Location = new System.Drawing.Point(362, 380);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(133, 58);
            this.btnlimpar.TabIndex = 78;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = false;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnlistar
            // 
            this.btnlistar.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btnlistar.Location = new System.Drawing.Point(208, 380);
            this.btnlistar.Name = "btnlistar";
            this.btnlistar.Size = new System.Drawing.Size(133, 58);
            this.btnlistar.TabIndex = 77;
            this.btnlistar.Text = "Listar";
            this.btnlistar.UseVisualStyleBackColor = false;
            this.btnlistar.Click += new System.EventHandler(this.btnlistar_Click);
            // 
            // btncadastrar
            // 
            this.btncadastrar.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btncadastrar.Location = new System.Drawing.Point(52, 380);
            this.btncadastrar.Name = "btncadastrar";
            this.btncadastrar.Size = new System.Drawing.Size(133, 58);
            this.btncadastrar.TabIndex = 76;
            this.btncadastrar.Text = "Cadastrar";
            this.btncadastrar.UseVisualStyleBackColor = false;
            this.btncadastrar.Click += new System.EventHandler(this.btncadastrar_Click);
            // 
            // txtmodelo
            // 
            this.txtmodelo.Location = new System.Drawing.Point(187, 50);
            this.txtmodelo.Name = "txtmodelo";
            this.txtmodelo.Size = new System.Drawing.Size(308, 23);
            this.txtmodelo.TabIndex = 75;
            // 
            // dgvlistar
            // 
            this.dgvlistar.BackgroundColor = System.Drawing.SystemColors.HotTrack;
            this.dgvlistar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvlistar.Location = new System.Drawing.Point(52, 160);
            this.dgvlistar.Name = "dgvlistar";
            this.dgvlistar.RowTemplate.Height = 25;
            this.dgvlistar.Size = new System.Drawing.Size(443, 214);
            this.dgvlistar.TabIndex = 74;
            // 
            // txtcor
            // 
            this.txtcor.Location = new System.Drawing.Point(187, 119);
            this.txtcor.Name = "txtcor";
            this.txtcor.Size = new System.Drawing.Size(308, 23);
            this.txtcor.TabIndex = 73;
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(52, 50);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(99, 23);
            this.txtid.TabIndex = 72;
            // 
            // lblmodelo
            // 
            this.lblmodelo.AutoSize = true;
            this.lblmodelo.Location = new System.Drawing.Point(187, 94);
            this.lblmodelo.Name = "lblmodelo";
            this.lblmodelo.Size = new System.Drawing.Size(26, 15);
            this.lblmodelo.TabIndex = 71;
            this.lblmodelo.Text = "Cor";
            // 
            // lbltamanho
            // 
            this.lbltamanho.AutoSize = true;
            this.lbltamanho.Location = new System.Drawing.Point(52, 94);
            this.lbltamanho.Name = "lbltamanho";
            this.lbltamanho.Size = new System.Drawing.Size(56, 15);
            this.lbltamanho.TabIndex = 70;
            this.lbltamanho.Text = "Tamanho";
            // 
            // lblplaca
            // 
            this.lblplaca.AutoSize = true;
            this.lblplaca.Location = new System.Drawing.Point(187, 21);
            this.lblplaca.Name = "lblplaca";
            this.lblplaca.Size = new System.Drawing.Size(48, 15);
            this.lblplaca.TabIndex = 69;
            this.lblplaca.Text = "Modelo";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(52, 21);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(18, 15);
            this.lblid.TabIndex = 68;
            this.lblid.Text = "ID";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(540, 500);
            this.Controls.Add(this.txttamanho);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnlistar);
            this.Controls.Add(this.btncadastrar);
            this.Controls.Add(this.txtmodelo);
            this.Controls.Add(this.dgvlistar);
            this.Controls.Add(this.txtcor);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.lblmodelo);
            this.Controls.Add(this.lbltamanho);
            this.Controls.Add(this.lblplaca);
            this.Controls.Add(this.lblid);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvlistar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txttamanho;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnlistar;
        private System.Windows.Forms.Button btncadastrar;
        private System.Windows.Forms.TextBox txtmodelo;
        private System.Windows.Forms.DataGridView dgvlistar;
        private System.Windows.Forms.TextBox txtcor;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.Label lblmodelo;
        private System.Windows.Forms.Label lbltamanho;
        private System.Windows.Forms.Label lblplaca;
        private System.Windows.Forms.Label lblid;
    }
}

